# Assets Directory

Place your custom pixel art here:

- `tileset.png` - 16×16 tile grid
- `player.png` - Character sprite sheet (16×24 per frame, 3 columns × 4 rows)

The game will use procedural graphics if these files are missing.
