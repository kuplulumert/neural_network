# Assets Klasörü

Özel piksel sanatınızı buraya ekleyin:

- `tileset.png` - 16×16 tile grid (Emerald tarzı)
- `player.png` - Karakter sprite sheet (16×24 per frame, 4 sütun × 4 satır)
- `panel9.png` - 9-slice diyalog paneli (24×24, her dilim 8×8)

Bu dosyalar yoksa oyun prosedürel grafikler kullanır.
